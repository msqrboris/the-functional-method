THE FUNCTIONAL METHOD — VERSION LISTA PARA NAMECHEAP

Qué subir a Namecheap:
- index.html
- styles.css

Dónde subirlo:
- Entra a Namecheap cPanel
- Abre File Manager
- Ve a public_html/
- Sube los archivos ahí

Si ya existe una página anterior:
- reemplaza index.html
- reemplaza styles.css

Pasos rápidos:
1. Entrar a Namecheap
2. cPanel
3. File Manager
4. public_html
5. Upload
6. Subir los archivos de este paquete
7. Abrir el dominio y revisar

Importante sobre Instagram:
- La sección de Instagram ya está preparada
- Para que los posts embebidos funcionen bien, conviene usar links directos de publicaciones, no solo el perfil

Contenido del paquete:
- index.html
- styles.css
- README-NAMECHEAP.txt
